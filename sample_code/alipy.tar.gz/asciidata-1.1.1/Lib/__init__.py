"""
$LastChangedBy: svn-mkuemmel $
$LastChangedDate: 2009-03-09 14:49:52 +0100 (Mon, 09 Mar 2009) $
$HeadURL: https://www.stsci.edu/svn/ssb/astrolib/trunk/asciidata/Lib/__init__.py $
"""
__version__ = "Version 1.1.1 $LastChangedRevision: 860 $"

from .asciifunction import *
